import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sync = readFileSync(resolve(root, 'public/js/10-sync-queue-pin.js'), 'utf8');
const receive = readFileSync(resolve(root, 'public/js/05-enterprise-repair.js'), 'utf8');
const sql = readFileSync(resolve(root, 'sql/SMART-POS-FULL-v13_4.sql'), 'utf8');

assert.match(sync, /\['adjust',\s*'sale',\s*'delete',\s*'return',\s*'payment',\s*'receive'\]\.includes\(op\.type\)/,
  'payment/receive operations must capture the employee session');
assert.match(sync, /p_reference:\s*p\.reference\s*\|\|\s*p\.transferReference\s*\|\|\s*null,\s*p_session:\s*p\.sessionToken\s*\|\|\s*null/,
  'customer payment RPC must pass p_session');
assert.match(sync, /p_pay_now:\s*!!p\.payNow,\s*p_session:\s*p\.sessionToken\s*\|\|\s*null/,
  'goods receipt RPC must pass p_session');
assert.match(receive, /selectedPayMode==='CASH'&&!ok\('PURCHASE'\)/,
  'cash payment during goods receipt must require PURCHASE permission');
assert.match(sql, /receive_customer_payment[\s\S]*?p_session uuid default null[\s\S]*?pos_check_perm\(p_session,\s*'CUSTOMER_PAY',\s*'STAFF'\)/,
  'receive_customer_payment must enforce CUSTOMER_PAY through employee session');
assert.match(sql, /receive_goods[\s\S]*?p_session uuid default null[\s\S]*?pos_check_perm\(p_session,\s*'GOODS_RECEIPT',\s*'MANAGER'\)/,
  'receive_goods must enforce GOODS_RECEIPT through employee session');
assert.match(sql, /if coalesce\(p_pay_now,\s*false\) then[\s\S]*?supplier_payments[\s\S]*?cash_ledger[\s\S]*?status = 'PAID'/,
  'p_pay_now must create supplier payment, cash expense, and mark AP paid');
assert.match(sql, /hashtextextended\('customer-payment:'[\s\S]*?hashtextextended\('goods-receipt:'/,
  'payment and receipt idempotency checks must be serialized');

console.log('ผ่าน: employee session, RPC permissions, immediate supplier payment, idempotency contracts');
